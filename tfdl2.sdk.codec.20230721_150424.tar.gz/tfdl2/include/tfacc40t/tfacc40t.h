//
// Created by huangyuyang on 10/14/21.
//

#ifndef TFACC_TFACC40T_H
#define TFACC_TFACC40T_H

#include "tfnn.h"
#include "memory.h"
#include "blasop.h"
#include "cache.h"
#include "convlayer.h"
#include "fclayer.h"
#include "retrieve.h"

#endif //TFACC_TFACC40T_H
